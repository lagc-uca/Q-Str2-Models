from qgis.gui import *
from qgis.PyQt.QtWidgets import QAction, QMainWindow, QDialog
from qgis.PyQt.QtCore import Qt
from qgis.core import *
from PyQt5.QtGui import QColor

class RectangleMapTool(QgsMapToolEmitPoint, QDialog):
  def __init__(self, canvas, parent):
   
    self.canvas = canvas
    self.parent = parent
    QgsMapToolEmitPoint.__init__(self, self.canvas)
    self.rubberBand = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)

    magenta_transp = QColor('#3388ff')
    magenta_transp.setAlpha(120)
  
    self.rubberBand.setColor(magenta_transp)
    self.rubberBand.setWidth(1)
    self.reset()

  def reset(self):
    self.startPoint = self.endPoint = None
    self.isEmittingPoint = False
    self.rubberBand.reset(True)

  def canvasPressEvent(self, e):
  
    self.startPoint = self.toMapCoordinates(e.pos())
    self.endPoint = self.startPoint
    self.isEmittingPoint = True
    self.showRect(self.startPoint, self.endPoint)
    
    

  def canvasReleaseEvent(self, e):
    self.isEmittingPoint = False

    r = self.rectangle()
    if r is not None:
      print("Rectangle:", r.xMinimum(),
            r.yMinimum(), r.xMaximum(), r.yMaximum()
           )

  def canvasMoveEvent(self, e):
    if not self.isEmittingPoint:
      return

    self.endPoint = self.toMapCoordinates(e.pos())
    self.showRect(self.startPoint, self.endPoint)

  def showRect(self, startPoint, endPoint):
    self.rubberBand.reset(QgsWkbTypes.PolygonGeometry)
    if startPoint.x() == endPoint.x() or startPoint.y() == endPoint.y():
      return

    point1 = QgsPointXY(startPoint.x(), startPoint.y())
    point2 = QgsPointXY(startPoint.x(), endPoint.y())
    point3 = QgsPointXY(endPoint.x(), endPoint.y())
    point4 = QgsPointXY(endPoint.x(), startPoint.y())
    
    self.rubberBand.addPoint(point1, False)
    self.rubberBand.addPoint(point2, False)
    self.rubberBand.addPoint(point3, False)
    self.rubberBand.addPoint(point4, True)    # true to update canvas
    self.rubberBand.show()

  def rectangle(self):
    if self.startPoint is None or self.endPoint is None:
      return None
    elif (self.startPoint.x() == self.endPoint.x() or \
          self.startPoint.y() == self.endPoint.y()):
      return None
    
    self.rellenaLineEdit()     
    return QgsRectangle(self.startPoint, self.endPoint)

  def deactivate(self):
    QgsMapTool.deactivate(self)
    self.deactivated.emit()
    
  def rellenaLineEdit(self):
       ######################################    
       # Create QgsGeometry from QgsPointXY
       sP_geom = QgsGeometry.fromPointXY (self.startPoint)
       eP_geom = QgsGeometry.fromPointXY (self.endPoint)
       # Prepare crs source and destination and instanciate a transform function
       # Prepara el crs origen y destino e instancia un funcion de transformacion de coordenadas
       active_Layer_CRS=self.canvas.currentLayer().crs().authid()
       destino_CRS="EPSG:"+self.parent.epsgIN.currentText()
       sourceCrs = QgsCoordinateReferenceSystem(active_Layer_CRS)
       destCrs = QgsCoordinateReferenceSystem(destino_CRS)
       tr = QgsCoordinateTransform(sourceCrs, destCrs, QgsProject.instance())
    
       sP_geom.transform(tr)
       self.sP = sP_geom.asPoint() # QgsPointXY    
    
       eP_geom.transform(tr)    
       self.eP = eP_geom.asPoint() # QgsPointXY
       #
       ###################################
       if self.sP.x() < self.eP.x():
            self.parent.xlonmin.setText(str(self.sP.x()))
            self.parent.xlonmax.setText(str(self.eP.x()))
       else:
            self.parent.xlonmin.setText(str(self.eP.x()))
            self.parent.xlonmax.setText(str(self.sP.x()))
        
       if self.sP.y() < self.eP.y():
            self.parent.ylatmin.setText(str(self.sP.y()))
            self.parent.ylatmax.setText(str(self.eP.y()))
       else:
            self.parent.ylatmin.setText(str(self.eP.y()))
            self.parent.ylatmax.setText(str(self.sP.y()))


